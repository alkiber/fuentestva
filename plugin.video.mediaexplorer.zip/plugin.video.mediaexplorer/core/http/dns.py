# -*- coding: utf-8 -*-
from core.libs import *
from core.proxytools import validate_ip
from lib.dns.resolver import Resolver
import hashlib


def Resolve(host, socks4=False):
    dnsmode = settings.get_setting('dns_mode', __file__)

    if validate_ip(host):  # IPs
        return host

    my_resolver = Resolver()
    cache_path = os.path.join(sysinfo.data_path, 'dnscache.json')
    encoded_host = hashlib.md5(six.ensure_binary(host)).hexdigest()

    if socks4 and not settings.get_setting('dns_proxy', __file__):
        # Socks4 requiere resolver la IP aqui, si dns_proxy = 0 se utilizan las dns del sistema por defecto
        # TODO: Parece que en android no obtiene las dns del sistema, por ahora usamos las de google.
        if my_resolver.nameservers == ['127.0.0.1']:
            my_resolver.nameservers = ['8.8.8.8', '8.8.4.4']

    elif dnsmode == 1:  # Cloudflare
        my_resolver.nameservers = ['1.1.1.1', '1.0.0.1']

    elif dnsmode == 2:  # Google
        my_resolver.nameservers = ['8.8.8.8', '8.8.4.4']

    elif dnsmode == 3:  # Personal
        primary = settings.get_setting('primary_dns', __file__)
        secondary = settings.get_setting('secondary_dns', __file__)
        dns = [primary]
        if secondary:
            dns.append(secondary)
        my_resolver.nameservers = dns

    try:
        dnscache = jsontools.load_file(cache_path)
        if dnscache.get('servers', '') != ', '.join(my_resolver.nameservers):
            dnscache = {
                'servers': ', '.join(my_resolver.nameservers),
                'records': {}
            }
    except Exception:
        dnscache = {
            'servers': ', '.join(my_resolver.nameservers),
            'records': {}
        }

    if encoded_host not in dnscache['records'] or dnscache['records'][encoded_host]['expires'] < time.time():
        logger.info('Solicitando DNS al servidor')
        response = my_resolver.query(host, 'a')
        dnscache['records'][encoded_host] = {
            'value': [a.to_text() for a in response],
            'expires': response.expiration
        }
        jsontools.dump_file(dnscache, cache_path)

    answer = dnscache['records'][encoded_host]['value']
    logger.info('Resolve: %s -> %s' % (host, answer))
    return answer
