# -*- coding: utf-8 -*-
# Sistema
import sys
import os
import re
import time
import datetime
from threading import Lock, RLock
from threading import Thread as _Thread


class LimitResults:
    """
    Clase para limitar los resultados de una función deve usarse como decorator:
        @limit
        def contents(item):
            ---
    La función deve tener el formato estandard con un solo parametro "item" y devolver un itemlist.
    Si la función devuelve mas items del limite, los limita cortando el itemlist y añadiendo un item para pasar a la si
    guiente parte.
    Si la función devuelve menos items del limite y el ultimo item es para pasar a siguiente pagina, va pasando paginas
    hasta llegar al limite.
    """
    def __init__(self, fnc):
        """
        Inicializa la clase y establece la función.
        :param fnc: función a ejecutar
        """
        self.limit = 30
        self.deep_limit = 5
        self.deep = 0
        self.item = None
        self.next_item = None
        self.page_items = 0
        self.itemlist = []
        self.fnc = fnc

    def get_itemlist(self):
        """
        Obtiene los items llamando a la función y elimina el item de página siguiente.
        :return:
        """
        # Llamamos a la función con el item como argumento
        itemlist = self.fnc(self.item)

        # Eliminamos el item para pagina siguiente en caso de existir y lo guarda para usarlo mas adelante
        if itemlist and itemlist[-1].type == 'next':
            self.next_item = itemlist[-1].clone(index=None)
            itemlist = itemlist[:-1]
        else:
            self.next_item = None

        # Numero de items de la ultima llamada, utilizado para saber el indice por donde cortar en la siguiente pagina
        self.page_items = len(itemlist)
        self.itemlist.extend(itemlist)

    def fill_itemlist(self):
        """
        Realiza llamadas a la función hata que el itemlist tenga el tamaño adecuado.
        :return:
        """
        # Vamos pasando paginas mientras haya un item de 'Página siguiente' y el itemlist no llegue al tamaño indicado
        while True:
            # Contabilizamos la profundidad en el listado
            self.deep += 1

            # Llamamos a la función
            self.get_itemlist()

            # Si venimos de un itemlist cortado, eliminamos los primeros x elementos (los de las páginas anteriores)
            if self.item.index:
                self.itemlist = self.itemlist[self.item.index:]

            # Si el itemlist no esta lleno y hay mas paginas, continuamos con la siguiente
            if len(self.itemlist) < self.limit and self.next_item and self.deep < self.deep_limit:
                self.item = self.next_item
            else:
                break

    def limit_itemlist(self):
        """
        Corta el itemlist para no sobrepasar el limite de resultados, añade un item para pagina siguiente:
         - Si es una pagina siguiente real, pasa el item obtenido de la funcion (con una nueva url)
         - Si es una pagina siguiente virtual, pasa el ultimo item, con el index por donde cortar en la siguiente pagina
        :return:
        """

        # Si el itemlist es mayor que el limite:
        if len(self.itemlist) > self.limit:
            index = self.page_items - (len(self.itemlist) - self.limit)
            self.itemlist = self.itemlist[:self.limit]

            next_page = self.item.clone(type='next', index=index)
        else:
            next_page = self.next_item

        # Añadimos el item para pasar de pagina
        if next_page:
            self.itemlist.append(next_page)

    def __call__(self, arg):
        # Segunda llamada: Se ejecuta la función y limita el resultado
        self.deep = 0
        self.item = arg
        self.fill_itemlist()
        self.limit_itemlist()
        return self.itemlist


class ResolveProgress:
    messages = {
        0: 'Descargando datos...',
        1: 'Obteniendo enlaces...',
        2: 'Desencriptando enlaces...',
        3: 'Desempaquetando javascript...',
        4: 'Resolviendo captcha...'
    }

    def __init__(self, completed, message):
        if isinstance(message, int):
            self.message = self.messages.get(message, '')
        else:
            self.message = message
        self.completed = completed

    def __repr__(self):
        return 'ResolveProgress(%d, %s)' % (self.completed, self.message)


class ResolveError(Exception):
    messages = {
        0: 'El archivo no existe o ha sido eliminado.',
        1: 'El archivo está siendo procesado.',
        2: 'Es necesaria una cuenta premium para poder reproducir el vídeo.',
        3: 'Es necesario el uso de un debrider con este servidor.',
        4: 'Sobrepasado el límite de visualizaciones.',
        5: 'El vídeo no tiene un formato compatible.',
        6: 'No se ha encontrado ninguna url válida.',
        7: 'El captcha es incorrecto.',
        8: 'Se ha producido un error ejecutando el código JS.'
    }

    def __init__(self, code):
        if isinstance(code, int):
            Exception.__init__(self, self.messages[code])
            self.code = code
        else:
            Exception.__init__(self, code)
            self.code = None

    def __repr__(self):
        return self.args[0]


def change_units(value):
    import math
    units = ["B", "KB", "MB", "GB"]
    if value <= 0:
        return "%.2f %s" % (0, units[0])
    else:
        return "%.2f %s" % (value / 1024.0 ** int(math.log(value, 1024)), units[int(math.log(value, 1024))])


if sys.version_info[0] < 3:
    # fix for datatetime.strptime returns None
    class proxydt(datetime.datetime):
        def __init__(self, *args, **kwargs):
            super(proxydt, self).__init__(*args, **kwargs)

        @classmethod
        def strptime(cls, date_string, format):
            return datetime.datetime(*(time.strptime(date_string, format)[0:6]))
    datetime.datetime = proxydt


class Thread(_Thread):
    def __stop(self):
        try:
            logger.logger_object.end_thread()
        finally:
            _Thread.__stop(self)


# MediaExplorer
from platformcode import platformsettings


class SysInfo():
    def __init__(self):
        self.runtime_path = platformsettings.runtime_path
        self.data_path = platformsettings.data_path
        self.temp_path = platformsettings.temp_path
        self.bookmarks_path = platformsettings.bookmarks_path
        self.os = sys.platform
        self.platform_name = platformsettings.platform_name
        self.platform_version = platformsettings.platform_version
        self.main_version = platformsettings.main_version
        self.py_version = '%d.%d.%d' % sys.version_info[0:3]
        self.profile = {}


def call_api(path, data=None):
    import random
    uuid = settings.get_setting('installation_id')
    if not uuid:
        settings.set_setting('installation_id', "%032x" % (random.getrandbits(128)))
        uuid = settings.get_setting('installation_id')

    if data is None:
        data = {'uid': uuid}
    else:
        data['uid'] = uuid
    return httptools.downloadpage(
        'http://api%d.mediaexplorer.tk/v1/%s%s' % (
            random.randint(0, 5),
            path,
            '?' + urllib_parse.urlencode(data) if data else ''
        ))


sysinfo = SysInfo()
sys.path.append(os.path.join(sysinfo.runtime_path, 'lib'))
sys.path.append(os.path.join(sysinfo.data_path, 'modules', 'lib'))
sys.path.append(os.path.join(sysinfo.data_path, 'modules'))

from six.moves import urllib_parse
from six.moves import reload_module
from six.moves import reduce
import six
from core import servertools
from core import settings
from core import logger
from core import jsontools
from core import moduletools
from core import scrapertools
from core import filetools
from core.item import *
from platformcode import platformtools
from core import httptools
from core.mediainfo import MediaInfo
from core import mediainfo
from core import bbdd
from core import proxytools

# Reloads
reload_module(logger)
reload_module(settings)
reload_module(platformsettings)
reload_module(platformtools)
reload_module(jsontools)
reload_module(servertools)
reload_module(moduletools)
reload_module(httptools)
reload_module(scrapertools)
reload_module(filetools)
reload_module(bbdd)
reload_module(proxytools)

# Inits
logger.init_logger()
settings.check_directories()
httptools.load_cookies()
sysinfo.profile = platformtools.get_profile()[1]
bbdd.create()
