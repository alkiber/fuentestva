# -*- coding: utf-8 -*-
from core.libs import *
import inspect


class Resolver(Thread):
    """
    Clase Resolver deriva de Thread ejecuta 'get_video_url' en el modulo del servidor en otro thread y notifica el
    progreso.
    """
    def __init__(self, item, module, params):
        # Parametros: item, modulo importado del servidor, dict con los datos del servidor.
        self.item = item
        self.module = module
        self.params = params

        # Indica el modo de funcionamiento, servidores con funcion en modo 'generator' (actualizan el progreso) o
        # funciones normales (solo devuelven el resultado)
        self.mode = None

        # Indica si se ha cancelado el proceso
        self.canceled = False

        # Mensaje de progreso inicial
        self.progress = ResolveProgress(0, "Conectando con %s" % self.params["name"])

        # Ultima actualización de estado por parte del servidor
        self.last_update = 0

        # Ultimo reporte de estado por parte de Resolver
        self.last_report = 0

        # Inicializamos el Thread
        Thread.__init__(self, target=self.resolve)

    def _wait(self):
        """
        Espera hasta el proximo reporte de estado.
        El reporte se envía cada 0.25 segundo o si el servidor envía una actualización de estado
        :return:
        """
        while time.time() - self.last_report < 0.25 and self.last_update < self.last_report:
            time.sleep(0.1)
        self.last_report = time.time()

    def _set_progress(self, progress):
        """
        Establece el progreso para reportarlo, si el proceso está cancelado envia una Excepción para que el Thread se
        detenga
        :param progress:
        :return:
        """
        if self.canceled:
            raise SystemExit()

        self.progress = progress
        self.last_update = time.time()

    def start(self):
        """
        Inicia el proceso para resolver las url y va devolviendo el progreso cada 0,25 segundos
        :return:
        """
        # Iniciamos el Thread
        Thread.start(self)

        # Esperamos el que el thread esté iniciado y se establezca el modo de funcionamiento
        while self.mode is None:
            time.sleep(0.1)

        # Modo 0: La función devuelve un unico resultado al terminar, no tenemos actualizaiones así que no sabemos como
        #         va el proceso. En este caso damos un tiempo máximo (10s) para finalizar, y va aumentando la barra de
        #         progreso si no ha devuelto un resultado en ese tiempo se da por cancelado
        if self.mode == 0:
            # De 0 a 40
            for x in range(41):
                # Esperamos para la siguiente actualización
                self._wait()
                # Enviamos el progreso que en este caso es siempre el mismo pero actualizando el %
                yield ResolveProgress(int(x/4.0*10), "Conectando con %s" % self.params["name"])

                # Si el progreso del servidor no es un ResolveProgres es que ya ha terminado
                if not isinstance(self.progress, ResolveProgress):
                    # Enviamos el resultado y terminamos
                    yield self.progress
                    return
            # Se han acabado los 10 segundo, cancelamos
            self.cancel()
        # Modo 1: El servidor va enviando progreso de estado, en este caso solo hay que reenviarlo
        else:
            # Mientras el progreso sea un ResolveProgress
            while isinstance(self.progress, ResolveProgress):
                # Esperamos a la siguiente actualización
                self._wait()
                # La enviamos.
                yield self.progress

    def resolve(self):
        """
        Ejecuta la función en el servidor para obtener la url
        :return:
        """
        logger.debug('Resolviendo: %s' % self.item.url)
        try:
            # Si la funcion es un 'generator'
            if inspect.isgeneratorfunction(self.module.get_video_url):
                # Modo 1
                self.mode = 1
                # Por cada actualización del servidor la almacenamos
                for status in self.module.get_video_url(self.item):
                    self._set_progress(status)
            # En caso contrario
            else:
                # Modo 0
                self.mode = 0
                # Almacenamos solo el retorno de la función
                self._set_progress(self.module.get_video_url(self.item))

        # Si se ha cancelado el progreso simplementa salimos sin mostrar ningun mensaje
        except SystemExit:
            return
        # Cualquier otro error, establecemos el progreso en Error y guardamos en el log
        except Exception:
            self._set_progress(ResolveError(6))
            logger.error()

    def cancel(self):
        """
        Cancela el proceso
        :return:
        """
        self.canceled = True



def get_servers_from_id(itemlist, fnc=None, sort=True):
    """
    Busca en un listado de items el servidor para cada uno, cuando la url no es valida
    basandose en el server id pasado por el canal
    :param itemlist: listado de servidores
    :param fnc: funcion encargada de devolver el label para cada item una vez asignado el servidor (obsoleto)
    :param sort: Ordena los servidores segun los favoritos
    :return: itemlist
    """
    logger.trace()
    list_servers = list()

    try:
        frame = inspect.currentframe()
        while not frame.f_locals.get('item'):
            frame = frame.f_back
        referer = frame.f_locals.get('item', Item()).url
    except Exception:
        referer = None

    # Obterner los servidores si es necesario
    if len(list(filter(lambda i: i.type == 'server', itemlist))):
        list_servers = moduletools.get_servers()

    # Recorremos el itemlist
    for item in itemlist:
        # Saltamos todos los que no sean servers
        if not item.type == 'server':
            continue

        # Recorremos los servers
        for server in list_servers:
            # Comprobamos el id y asignamos los datos en caso de coincidencia
            if item.server == server['id'] or item.server in server.get('ids', []):
                item.servername = server['name']
                item.serverimage = server.get('serverimage', 'thumb/%s.png' % server['id'])
                item.server = server['id']
                if server.get('settings'):
                    item.context = [{
                        'label': 'Configurar servidor %s' % server['name'],
                        'action': 'config_channel',
                        'channel': 'settings',
                        'path': server['path']
                    }]
                break

        # Asignamos el label (obsoleto)
        if fnc:
            item.label = fnc(item)

        item.referer = referer

        # Si no se ha encontrado se marca como desconocido
        if not item.servername:
            logger.debug('Servidor no disponible para: \'%s\'' % item.server)
            item.servername = 'Desconocido'
            item.server = 'directo'
            item.serverimage = 'thumb/server_unknow.png'

    # Filtrar si es necesario
    new_itemlist = filter_servers(itemlist)

    # Ordenar segun favoriteslist si es necesario
    if sort:
        itemlist = sort_servers(new_itemlist)

    return itemlist


def get_servers_itemlist(itemlist, fnc=None, sort=True):
    """
    Busca en un listado de items el servidor de cada uno y lo asigna
    :param itemlist: listado de servidores
    :param fnc: funcion encargada de devolver el label para cada item una vez asignado el servidor (obsoleto)
    :param sort: Ordena los servidores segun los favoritos
    :return: itemlist
    """
    logger.trace()

    try:
        frame = inspect.currentframe()
        while not frame.f_locals.get('item'):
            frame = frame.f_back
        referer = frame.f_locals.get('item', Item()).url
    except Exception:
        referer = None

    num_servers = len(list(filter(lambda i: i.type == 'server', itemlist)))

    # Recorre los servidores
    for server_path in moduletools.get_paths_servers():
        if num_servers > 0:
            server = jsontools.load_file(server_path)
            # Recorre los patrones
            for pattern in server.get("find_videos", {}).get("patterns", []):
                logger.info(pattern["pattern"])
                # Recorre los resultados
                for match in re.compile(pattern["pattern"], re.DOTALL | re.M).finditer(
                        "\n".join([item.url for item in itemlist if not item.server])):
                    url = pattern["url"]
                    for x in range(len(match.groups())):
                        url = url.replace("\\%s" % (x + 1), match.groups()[x])

                    for item in itemlist:
                        if match.group() in item.url and not item.server:
                            num_servers -= 1
                            item.serverimage = server.get('serverimage', 'thumb/%s.png' % server['id'])
                            item.server = server['id']
                            item.servername = server['name']
                            item.urlresolver = item.url
                            item.url = url
                            if server.get('settings'):
                                item.context = [{
                                    'label': 'Configurar servidor %s' % server['name'],
                                    'action': 'config_channel',
                                    'channel': 'settings',
                                    'path': server_path
                                }]

    for item in itemlist:
        # Otros items que puedan haber no se tocan
        if not item.type == 'server':
            continue

        # Asignamos el label (obsoleto)
        if fnc:
            item.label = fnc(item)

        item.referer = referer

        # Si no se ha encontrado se marca como desconocido
        if not item.server:
            logger.debug('Servidor no disponible para: \'%s\'' % item.url)
            item.servername = 'Desconocido'
            item.server = 'directo'
            item.serverimage = 'thumb/server_unknow.png'

    # Filtrar si es necesario
    itemlist = filter_servers(itemlist)

    # Ordenar segun favoriteslist si es necesario
    if sort:
        itemlist = sort_servers(itemlist)

    return itemlist


def normalize_url(item):
    """
    Normaliza la url segun el patron del .json
    :param item: item a normalizar
    :return: item
    """
    logger.trace()
    path = os.path.join(sysinfo.data_path, 'modules', 'user_servers', item.server + '.json')
    if not os.path.isfile(path):
        path = os.path.join(sysinfo.runtime_path, 'servers', item.server + '.json')

    server = moduletools.get_module_parameters(path)
    for pattern in server.get("find_videos", {}).get("patterns", []):
        for match in re.compile(pattern["pattern"], re.DOTALL).finditer(item.url):
            url = pattern["url"]
            for x in range(len(match.groups())):
                url = url.replace("\\%s" % (x + 1), match.groups()[x])
            item.urlresolver = item.url
            item.url = url
            break

    return item


def resolve_video_urls(item):
    """
    Resuelve la url del servidor en una reproducible
    :param item:
    :return:
    """
    logger.trace()

    if item.server == 'directo':
        return [Video(url=item.url, server='Directo')]

    if item.server == 'local':
        return [Video(url=item.url, server='Local')]

    # Importamos el servidor
    server = moduletools.get_server_module(item.server)

    # Obtenemos los debriders disponibles para el servidor
    debriders = list(filter(lambda x: item.server in x['servers'], moduletools.get_debriders()))

    # Obtenemos los parametros del servidor
    server_parameters = moduletools.get_module_parameters(server.__file__)

    # Mostramos el dialogo
    dialog = platformtools.dialog_progress("MediaExplorer", "Conectando con %s" % server_parameters["name"])

    # Buscamos la url en el servidor
    # Usamos Resolver para ejecutar la función en un nuevo thread y notificar el progreso, de este modo se puede
    # cantelar el proceso en cualquier momento.

    result = None
    # Creamos la instancia de Resolver con el item, el modulo importado y los parametros del servidor
    resolver = Resolver(item, server, server_parameters)

    # Iniciamos el proceso nos mantenemos esperando las actualizaciónes de estado.
    # Estas se envian cada 0.25 segundos o cuando haya un cambio de estado por parte del servidor.
    for status in resolver.start():
        # Si hemnos cancelado, cancelamos el resolver y salimos
        if dialog.iscanceled():
            resolver.cancel()
            break
        # Si el progreso es un ResolveProgres, actualizamos el dialog
        if isinstance(status, ResolveProgress):
            dialog.update(status.completed, status.message)
        # Cualquier otra cosa, se entiende que el proceso ha terminado, y este es el valor de retorno
        else:
            result = status
            break

    # Cancelado
    if result is None:
        return

    # Si el resultado es un str es que se ha producido un error o el video no existe, ponemos el str en el itemlist
    if isinstance(result, Exception):
        itemlist = '[%s] %s' % (server_parameters['name'], result)

    # Si el resultado es un list es que tenemos enlaces, los pasamos al itemlist
    else:
        itemlist = result

    # Si no tenemos enlaces o aún teniendolos la configuración marca que busquemos en los debriders, buscamos
    if not type(itemlist) == list or not itemlist or not settings.get_setting('resolve_stop', __file__):
        for debrider in debriders:
            if dialog.iscanceled():
                break

            # Importamos el debrider
            mod = moduletools.get_debrider_module(debrider['id'])
            dialog.update(int((debriders.index(debrider) + 1) * 100 / (len(debriders) + 1)),
                          "Conectando con %s" % debrider["name"])

            # Probamos con el debrider
            try:
                result = mod.get_video_url(item)
            except Exception as e:
                result = e
                logger.error()

            # Si teniamos un error en el itemlist y aqui obtenemos otro, lo añadimos a una nueva linea
            if type(itemlist) == str:
                if isinstance(result, Exception):
                    itemlist += '\n[%s] %s' % (debrider['name'], result)

                # Si teniamos un error en el itemlist pero aquí tenemos enlaces, borramos el error y ponemos los enlaces
                else:
                    itemlist = result

            # Si ya teniamos enlaces y aqui obtenemos mas enlaces, los añadimos
            else:
                if type(result) == list:
                    itemlist.extend(mod.get_video_url(item))

            # Si tenemos enlaces y la configuración marca que no sigamos buscando, paramos
            if type(itemlist) == list and itemlist and settings.get_setting('resolve_stop'):
                break

    dialog.update(100, "Terminado")

    dialog.close()

    # Ordenamos el itemlist
    def __res2int(i):
        res = re.sub(r"(\d+)[kK]", '\\g<1>000', i.res)
        res = re.sub(r"Original", '10000', res)  # La resolucion original, sea cual sea, siempre sera mayor q el resto
        filetype = i.type

        typeorder = ('rtmp', '.mpd', '.m3u8')  # Orden de prioridad de menor a moyor los que no esten aqui son mayores

        if filetype in typeorder:
            res += str(typeorder.index(filetype))
        else:
            res += str(len(typeorder))

        try:
            return int(re.findall(r"(\d+)", res)[0])
        except Exception:
            return 0

    if type(itemlist) == list:
        itemlist = sorted(itemlist, key=__res2int, reverse=True)

    # Si no tenemos error, pero tampoco tenemos enlaces, añadimos un error generico
    if not itemlist:
        itemlist = ResolveError(6)
        logger.debug('No se ha encontrado ningúna url válida para: %s' % item.url)

    return itemlist


def sort_servers(servers_list, priority=5):
    """
    Ordena los servidores por tres criterios:
        1. Los items que no sean servers los primeros.
        2. Los servers que esten marcados como 'stream' antes que los que no.
        3. Por ultimo se ordenan segun el parametro priority.

    :param servers_list: itemlist con servidores
    :param priority:
                0 _ No ordenar
                1_ Servidores y calidades
                2_ Calidades y servidores
                3_ Solo servidores
                4_ Solo calidades
                5_(Por defecto) Segun el valor guardado en la configuracion
    :return: itemlist ordenado
    """
    logger.trace()
    order_list = [settings.get_setting('priority_%s' % x, __file__) for x in range(10)]

    if priority > 4:
        priority = settings.get_setting('sort_servers', __file__)

    lambda_priority = [
        # No ordenar
        lambda y: (bool(y.server),
                   not y.stream,
                   0
                   ),
        # Servidores y calidades
        lambda y: (bool(y.server),
                   not y.stream,
                   order_list.index(y.server) if y.server in order_list else 100,
                   1000 - y.quality.level if y.quality else 1000
                   ),
        # Calidades y servidores
        lambda y: (bool(y.server),
                   not y.stream,
                   1000 - y.quality.level if y.quality else 1000,
                   order_list.index(y.server) if y.server in order_list else 100
                   ),
        # Solo servidores
        lambda y: (bool(y.server),
                   not y.stream,
                   order_list.index(y.server) if y.server in order_list else 100
                   ),
        # Solo calidades
        lambda y: (bool(y.server),
                   not y.stream,
                   1000 - y.quality.level if y.quality else 1000
                   )
    ]

    servers_list = sorted(
        servers_list,
        key=lambda_priority[priority]
    )

    return servers_list


def filter_servers(servers_list):
    """
    Filtra los servidores quitando los que estén desactivados o deshabilitados en la configuración y ocultando
    si es necesario los servidores Desconocidos
    :param servers_list: itemlist con servidores
    :return: itemlist filtrado
    """
    hide_list = set()

    servers = moduletools.get_servers()
    active = dict([(s['id'], s['active']) for s in servers])
    recaptcha = dict([(s['id'], s.get('recaptcha', False)) for s in servers])

    # Ocultar servidores que usan reCaptcha
    if settings.get_setting('hide_items', os.path.join(sysinfo.runtime_path, 'recaptcha', 'recaptcha.json')):
        hide_list.update(list(filter(
            lambda x: recaptcha.get(x.server, False),
            servers_list
        )))

    # Ocultar servidores desconocidos
    if settings.get_setting('hide_servers_unknown', __file__):
        hide_list.update(list(filter(
            lambda x: x.servername == 'Desconocido',
            servers_list
        )))

    # Ocultar servidores desactivados (json)
    hide_list.update(list(filter(
        lambda x: not active.get(x.server, True),
        servers_list
    )))

    # Ocultar servidores desactivados (usuario)
    hide_list.update(list(filter(
        lambda x: settings.get_setting("disabled", os.path.join(sysinfo.runtime_path, 'servers', '%s.json' % x.server)),
        servers_list
    )))

    return list(filter(lambda x: x not in hide_list, servers_list))


def autoplay(itemlist, item):
    """
    Funcion que intenta reproducir un video del itemlist automaticamente despues de filtrar y ordenar el listado.
        1. Se eliminan los enlaces de servidores 'Desconocidos' (no suelen funcionar) y los del tipo 'download'
        2. Se eliminan todos los enlaces que no correspondan al "Idioma preferido de reproducción" fijado en Ajustes.
        3. Se eliminan los enlaces cuya calidad este incluida en 'disabled_qualities'
        4. Se ordena el listado resultante segun el criterio 'Ordenar enlaces' dentro de la
           "Configuración general de servidores"

    :param itemlist: Listado de items devuelto por la funcion 'findvideos'
    :param item: Elemento del menu que invoco a 'findvideo'
    :return: True en el caso de que se haya podido reproducir en video. False en caso contrario.
    """
    logger.trace()
    autoplay_list = itemlist
    del item

    # Informa que AutoPlay esta activo
    dialog = platformtools.dialog_progress_bg('AutoPlay', 'Iniciando...')

    # Filtrar solo streaming (excepto server='directo') y del idioma predeterminado
    lang_autoplay = sorted(Languages().all, key=lambda obj: obj.label)[settings.get_setting('autoplay_lang_fav')]
    try:
        autoplay_list = list(filter(
            lambda x: x.type == 'server' and x.stream and x.server != 'directo' and x.lang.name == lang_autoplay.name,
            autoplay_list
        ))
    except Exception:
        lang_autoplay = Languages.from_name('unk')

    # Filtrado por calidades
    if settings.get_setting('quality_filter_server'):
        disabled_qualities = settings.get_setting('disabled_qualities') or []
        autoplay_list = list(filter(
            lambda x: x.quality.name not in disabled_qualities,
            autoplay_list
        ))

    if not autoplay_list:
        # No hay enlaces que satisfagan todos los filtros
        dialog.update(100, 'AutoPlay', 'No hay enlaces que cumplan todos los filtros')
        time.sleep(2)
        dialog.close()
        return False

    # Ordenar segun la prioridad seleccionada
    autoplay_list = servertools.sort_servers(autoplay_list, settings.get_setting('sort_servers', __file__))

    # Si se esta reproduciendo algo detiene la reproduccion
    if platformtools.is_playing():
        platformtools.stop_video()

    # Recorrer la lista intentando encontrar uno funcional
    max_intentos = int(settings.get_setting('autoplay_max_intentos', getvalue=True))
    max_intentos_servers = {}

    for autoplay_elem in autoplay_list:
        if not platformtools.is_playing():
            if autoplay_elem.server not in max_intentos_servers:
                max_intentos_servers[autoplay_elem.server] = max_intentos

            # Si se han alcanzado el numero maximo de intentos de este servidor saltamos al siguiente
            if max_intentos_servers[autoplay_elem.server] == 0:
                continue

            dialog.update(int((autoplay_list.index(autoplay_elem) + 1) * 100 / (len(autoplay_list) + 1)),
                          'AutoPlay',
                          "%s [%s] %s" % (
                              autoplay_elem.servername,
                              lang_autoplay.label,
                              ("(%s)" % autoplay_elem.quality.label) if isinstance(autoplay_elem.quality,
                                                                                   Language) else ''
                          ))

            # Intenta reproducir los enlaces
            from core import launcher
            launcher.run(autoplay_elem.clone(autoplay=True))

            if platformtools.is_playing():
                dialog.close()
                return True
            else:
                max_intentos_servers[autoplay_elem.server] -= 1

                # Si se han alcanzado el numero maximo de intentos de este servidor
                # preguntar si queremos seguir probando o lo ignoramos
                if max_intentos_servers[autoplay_elem.server] == 0:
                    text = "Parece que los enlaces de %s no estan funcionando.\n" % autoplay_elem.servername
                    if not platformtools.dialog_yesno("AutoPlay", text + "¿Desea ignorar todos los enlaces de este servidor?"):
                        max_intentos_servers[autoplay_elem.server] = max_intentos

    dialog.update(100, 'No ha sido posible reproducir ningún enlace automáticamente')
    time.sleep(2)
    dialog.close()
    return False


def config(item):
    return platformtools.show_settings(title=item.label)
