# -*- coding: utf-8 -*-
from core.libs import *

HOST = "https://www.pornhd.com"


def mainlist(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action='videos',
        label='Útimos videos',
        type='item',
        url=HOST,
        content_type='videos'
    ))

    itemlist.append(item.clone(
        action='videos',
        label='Los más valorados',
        type='item',
        url=HOST + '/?order=top-rated',
        content_type='videos'
    ))

    itemlist.append(item.clone(
        action='videos',
        label='Los más vistos',
        type='item',
        url=HOST + '/?order=most-popular',
        content_type='videos'
    ))

    itemlist.append(item.clone(
        action='categorias',
        label='Categorias',
        type='item',
        url=HOST + '/category?order=alphabetical',
        content_type='items'
    ))

    itemlist.append(item.clone(
        action='canales',
        label='Canales',
        type='item',
        url=HOST + "/channel",
        content_type='items'
    ))

    itemlist.append(item.clone(
        action='canales',
        label='PornStars',
        type='item',
        url=HOST + "/pornstars",
        content_type='items'
    ))

    itemlist.append(item.clone(
        action='search',
        label='Buscar',
        type='search',
        content_type='videos',
        category='adult',
        query=True
    ))

    return itemlist


def videos(item):
    logger.trace()
    itemlist = list()

    # Descarga la página
    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    # Extrae las peliculas
    patron = r'<div class="video-item ">.*? href="([^"]+)".*?srcset="([^"]+)" type="image/jpeg".*?' \
             r'<span class="video-duration">([^<]+).*?<a href="[^>]+>([^<]+)'

    for url, thumbnail, duracion, title in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            action='play',
            title=title,
            url=HOST + url,
            thumb=thumbnail,
            folder=False,
            type='video'
        ))

    if itemlist:
        # Paginador
        url = scrapertools.find_single_match(data, r'<a class="pagination-next" href="([^"]+)"')
        if url:
            itemlist.append(item.clone(action='videos', url=url, type='next'))

    return itemlist


def categorias(item):
    logger.trace()
    itemlist = list()

    # Descarga la página
    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    # Extrae las categorias
    patron = '<a href="([^"]+)" class="column is-4-mobile is-2-tablet is-1-widescreen has-text-weight-bold ' \
             'small-thumbpoptrigger"><picture class="image mb-1 is-4by5">.*?srcset="([^"]+)" type="image/jpeg">.*?' \
             '<div class="small-thumb-title">([^<]+)'

    for url, thumbnail, label in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            action='videos',
            label=label.strip(),
            poster=urllib_parse.urljoin(item.url, thumbnail),
            url=urllib_parse.urljoin(item.url, url),
            content_type='videos',
            type='item'
        ))

    return itemlist


def canales(item):
    logger.trace()
    itemlist = list()

    # Descarga la página
    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    # Extrae las categorias
    patron = r'<a href="([^"]+)" class="column is-4-mobile is-2-tablet is-1-widescreen has-text-weight-bold ' \
             r'small-thumb poptrigger"><picture class="image mb-1 is-4by5">.*?src="([^"]+)".*?' \
             r'<div class="small-thumb-title">([^<]+)'

    for url, thumbnail, label in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            action='videos',
            label=label.strip(),
            poster=urllib_parse.urljoin(item.url, thumbnail),
            url=urllib_parse.urljoin(item.url, url),
            content_type='videos',
            type='item'
        ))

    return itemlist


def search(item):
    logger.trace()
    item.url = HOST + "/search?search=" + item.query
    return videos(item)


def play(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(httptools.downloadpage(item.url).data)

    for url, tipo, res in scrapertools.find_multiple_matches(data,
                                                             """<source src="([^"]+)" type='([^']+)'.*?res='([^']+)"""):
        url = \
            httptools.downloadpage(url, headers={'Referer': item.url}, follow_redirects=False,
                                   only_headers=True).headers[
                'location']
        itemlist.append(Video(url=url, res=res, type=tipo))

    return sorted(itemlist, key=lambda x: int(x.res[:-1]) if x.res else 0, reverse=True)
