# -*- coding: utf-8 -*-
from .. import BaseSolver
from core.libs import *


class CaptchaSolver(BaseSolver):
    base_url = 'https://2captcha.com'

    def __init__(self, *args, **kwargs):
        BaseSolver.__init__(self, *args, **kwargs)
        self.api_key = settings.get_setting('api_key', __file__)
        self.task_id = None

    def is_enabled(self):
        if not settings.get_setting('enabled', __file__):
            return False

        if not self.api_key:
            return False

        if not self.get_balance():
            return False

        return True

    def get_balance(self):
        try:
            return float(self._api_request(
                '/res.php?',
                get={
                    'action': 'getbalance',
                    'json': 1
                }
            )['request'])
        except Exception:
            return 0.0

    def _api_request(self, url, get=None):
        if get is None:
            get = {}

        get['key'] = self.api_key

        response = httptools.downloadpage(self.base_url + url + urllib_parse.urlencode(get))

        if response.sucess:
            data = jsontools.load_json(response.data)
            if data.get('status') != 1:
                raise Exception(data['request'])
            return data
        else:
            raise Exception('Error al conectar con la api, error code: %s' % response.code)

    def solve_v3(self, site_url, site_key, action, min_score):
        self.task_id = self._api_request(
            '/in.php?',
            get={
                'method': 'userrecaptcha',
                'googlekey': site_key,
                'pageurl': site_url,
                'action': action,
                'min_score': min_score or '0.3',
                'version': 'v3',
                'json': 1
            }
        )['request']

    def solve_v2(self, site_url, site_key):
        self.task_id = self._api_request(
            '/in.php?',
            get={
                'method': 'userrecaptcha',
                'googlekey': site_key,
                'pageurl': site_url,
                'json': 1
            }
        )['request']

    def get_response(self):
        try:
            data = self._api_request(
                '/res.php?',
                get={
                    'action': 'get',
                    'id': self.task_id,
                    'json': 1
                }
            )
        except Exception as e:
            if e.args[0] == 'CAPCHA_NOT_READY':
                for x in range(5):
                    if self.canceled:
                        return
                    time.sleep(1)
                if self.canceled:
                    return
                self.get_response()
            else:
                self.result = e
        else:
            self.result = data['request']
